Find this game online at <https://jasonyundt.website/gitweb?p=simple-brick-breaker>.

Get this game’s source code:
	git clone https://jasonyundt.website/git/simple-brick-breaker

Learn how to contribute to this game at <https://jasonyundt.website/submitting-patches.html>.
